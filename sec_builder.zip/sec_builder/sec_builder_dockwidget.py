import os
from PyQt4 import QtGui, uic
from PyQt4.QtCore import pyqtSignal,pyqtSlot


import pi
from PyQt4.QtCore import QSettings,pyqtSignal
from qgis.core import QgsMapLayerRegistry#,QgsDataSourceURI
import remake_layer as r
from qgis.utils import iface



FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'sec_builder_dockwidget_base.ui'))


class sec_builderDockWidget(QtGui.QDockWidget, FORM_CLASS):

    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        """Constructor."""
        super(sec_builderDockWidget, self).__init__(parent)
        self.setupUi(self)
        
        
        self.connect.clicked.connect(self.con)
        self.make_button.released.connect(self.make)
        self.make_button.clicked.connect(self.save_config)
        self.RL.clicked.connect(self.refresh_list)
        self.table.currentIndexChanged.connect(self.table_change)
        self.table.activated.connect(self.table_set)

        self.column.activated.connect(self.column_change)

        self.cols={}
        self.load_config()
        
        self.con()
        self.status.setText('Idle')
        self.num.valueChanged.connect(self.make_sec)
        self.refresh_list()
        self.q=False


    def load_config(self):
        settings=QSettings('pts', 'sec_builder')

        p=settings.value('port')
        if isinstance(p,basestring):
            self.port.setText(p)
            
        h=settings.value('host')
        if isinstance(h,basestring):
            self.host.setText(h)
            
        db=settings.value('db_name')
        if isinstance(db,basestring):
            self.db_name.setText(db)
            
        u=settings.value('user')
        if isinstance(u,basestring):
            self.user.setText(u)
            
        p=settings.value('password')
        if isinstance(p,basestring):
            self.password.setText(p)
            
        n=settings.value('num')
        if isinstance(n,int):
            self.num.setValue(n)
            
        v=settings.value('cols')
        if isinstance(v,dict):
            self.cols=v
        

    def save_config(self):
        settings=QSettings('pts', 'sec_builder')
        settings.setValue('port',self.port.text())
        settings.setValue('host',self.host.text())
        settings.setValue('db_name',self.db_name.text())
        settings.setValue('user',self.user.text())
        settings.setValue('password',self.password.text())
        settings.setValue('num',self.num.value())

        
    def con(self):
        self.connection=pi.pi(self.host.text(),self.db_name.text(),self.user.text(),self.password.text(),port=self.port.text())
        if self.connection.test():
            self.save_config()
            self.connected_label.setText('Connected')
            self.refresh_tables()

            
            #move to table from saved settings if available
            i=self.table.findText(QSettings('pts', 'sec_builder').value('table'))#-1 if not found
            self.table.setCurrentIndex(i)#-1 sets to nothing        
            
        else:
            self.connected_label.setText('Not connected')
            self.table.clear()


    def refresh_tables(self):
        t=self.connection.list_tables()
        self.table.clear()
        self.table.addItems(t)    

#causes column_change
    def table_change(self):
        t=self.table.currentText()
        if self.connection.test():
            cols=self.connection.list_cols(table=t)
            
            self.column.clear()
            self.column.addItems(cols)

            #move to column from saved settings if available
            t=self.table.currentText()
            if t in self.cols:
                i=self.column.findText(self.cols[t])#-1 if not found
                self.column.setCurrentIndex(i)    
            
    def table_set(self):
        QSettings('pts', 'sec_builder').setValue('table',self.table.currentText())


        
    def column_change(self):
        table=self.table.currentText()
        c=self.column.currentText()
        
        if table in self.cols:
            self.cols[table]=c
        else:
            self.cols.update({table:c})

        QSettings('pts', 'sec_builder').setValue('cols',self.cols)

     
    def display(self,s):
        print(s)


    def refresh_list(self):
        self.run_layer.clear()
        layers = [layer.name() for layer in QgsMapLayerRegistry.instance().mapLayers().values()]
        self.run_layer.addItems(layers)        

            
    def make(self):
        self.result.setText('')
        #error if not connected
        if self.connected_label.text()=='Not connected':
            self.error('Not connected to database')
            return
        
        run=self.run_layer.currentText()

        if run=='':
            self.error('No layer selected')
            return
        
        self.remake_layer()
        self.upload_layer()
        self.query_database()
        self.set_secs()
        self.make_sec()

        
    def remake_layer(self):
        self.status.setText('Creating new layer...')
        self.repaint()
        
        try:
            run=self.run_layer.currentText()
            la=QgsMapLayerRegistry.instance().mapLayersByName(run)[0]
            r.remake_layer(la,self.new_layer.text())
            self.layer=QgsMapLayerRegistry.instance().mapLayersByName(self.new_layer.text())[0]
            self.refresh_list()
            
        except:
            self.error('Error remaking layer')


    def upload_layer(self):
        self.status.setText('Uploading layer to database...')
        self.repaint()
        A='run'#self.new_layer.text()
        self.connection.drop_table(A)
        try:
            self.connection.drop_table(A)
        except:
            self.error('Error dropping previous table run',set_text=False)
            return

        #uploading layer
        try:            
            self.connection.upload_layer(self.layer,A)
            
        except:
            self.error('Error uploading layer')
            return

    def query_database(self):
        self.status.setText('Querying database...')
        self.repaint()

        try:
            self.q=self.connection.secs_query(A='run',B=self.table.currentText(),col=self.column.currentText(),buffer_size=self.buffer_size.value())
            #drop table        
            try:
                self.connection.drop_table('run')
            except:
                self.error('Could not drop table run',set_text=False)

        except:
            self.error('Error querying database. Is table correct?')
            return


    #q=list-query results
    def set_secs(self):
        self.status.setText('Setting values...')
        self.repaint()
        try:
            r.set_secs(self.layer,self.q,{1:1,2:2,3:3})
            
        except:
            self.error('Error setting values')

    
    #q=list-query results
    def make_sec(self):
        self.status.setText('Listing sections...')
        self.repaint()
        try:
            s=r.get_sec(self.q,self.num.value())
            self.result.setText(', '.join(s))
            self.status.setText('Idle')
        except:
            if self.q:
                self.error('Error making results into sec')
            

    def error(self,e,set_text=True):
        self.message(e)
        if set_text:
            self.status.setText('Quit with error')
            self.result.setText('')
        
        
    def message(self,e,t=20):
        bar=iface.messageBar()
        bar.pushMessage("sec_builder error",e,duration=t)


    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()


        



        
        
        
            
        




