
from qgis.core import QgsVectorLayer,QgsField,QgsFeature,QgsMapLayerRegistry
from PyQt4.QtCore import QVariant

def remake_layer(layer_in,name='results'):
#make new layer
    layer=QgsVectorLayer('Point?crs=epsg:27700',name, 'memory')
    p=layer.dataProvider()
    layer.startEditing()
    
    fields=[ QgsField("id",QVariant.Int),QgsField("sec",QVariant.String),QgsField("result",QVariant.Int),QgsField("chainage",QVariant.Int)]
    p.addAttributes(fields)
    #copy relevant attributes
    feats=[]
    fields=layer.fields()
    
    for i in layer_in.getFeatures():
        f=QgsFeature()
        f.setFields(fields)
        f.setGeometry(i.geometry())
        #f.setAttributes([0,'D'])
        f.setAttributes([0,'D',i['result'],i['chainage']])#takes list, 1 element per attribute
        feats.append(f)
   
    p.addFeatures(feats)
    layer.commitChanges()
    QgsMapLayerRegistry.instance().addMapLayer(layer)
  #set id attribute
    layer.startEditing()
    for f in layer.getFeatures():
        id=f.id()
        layer.changeAttributeValue(f.id(),0,id)
    layer.commitChanges()
    
    
def set_secs (layer,results,colmap):
    #colmap = {results_col:layer_col,...}
    layer.startEditing()
    for line in results:
        for i in colmap:
            #line[0]=feature id
            layer.changeAttributeValue(line[0],colmap[i],line[colmap[i]])#feature id, index, new value
    layer.commitChanges()


#lists sections in query results q.
#adds 'D' where gap>10m or wheel up.
#ignores sections with <t results and not D

def get_sec(q,t):
    secs=[]
    last=q[-1]
    for row in q:
        sec=row[1]
        if row[2]<25:#result<25 means wheel up
            sec='D'  
        if row[3]-last[3]>10:#gap>10m
            sec='D'
        secs.append(sec)

    #group by section
    r=[]
    last=''
    for s in secs:
        if s!=last:
            r.append({'sec':s,'n':1})
        else:
            r[-1]['n']+=1

        last=s
    
    #ignore where n<amount and not 'D'
    L=[]
    for i in r:
        if i['sec']=='D' or i['n']>t:
            L.append(i['sec'])

    return L
