import psycopg2
from qgis.core import QgsDataSourceURI,QgsVectorLayerImport

class pi:
    def __init__(self,host,db_name,user,password='',port='5432'):
        self.host=host
        self.db_name=db_name
        self.user=user
        self.password=password
        self.port=port
        

    def test(self):
        try:
            con = psycopg2.connect(host=self.host,dbname=self.db_name,user=self.user,password=self.password,port=self.port)
            con.close()
            return True
        except:
            return False


    def get_query(self,q,to_dict=False,cols=[]):
        con = psycopg2.connect(host=self.host,dbname=self.db_name,user=self.user,password=self.password,port=self.port)
        c=con.cursor()
        c.execute(q)
        if to_dict:
            return self.query_to_dict(c.fetchall(),cols)
        else:
            return c.fetchall()
        con.close()


    def query_to_dict(self,res,cols):
        #print(res)
        d={}
        for c in cols:
            d.update({c:[]})
      
        for i,c in enumerate(cols):
            for row in res:
                d[c].append(row[i])
        return d
    
            
    def list_tables(self,schema='public',Q=False):
        q="SELECT table_name\n"
        q+="FROM information_schema.tables\n"
        q+="WHERE table_schema='"+schema+"'\n"
        q+="ORDER BY table_schema,table_name;"
        if Q:
            return q
        else:
            L=self.get_query(q)
            return [row[0] for row in L]

    def list_cols(self,table,schema='public',Q=False,t='character varying'):
        q="SELECT column_name FROM information_schema.columns\n"
        q+="WHERE table_schema = '"+schema+"'\n"
        q+="AND table_name   = '"+table+"'"
        q+="AND data_type='"+t+"'"
        if Q:
            return q
        else:
            L=self.get_query(q)
            return [row[0] for row in L]

  
    def sql(self,q):
        con = psycopg2.connect(host=self.host,dbname=self.db_name,user=self.user,password=self.password,port=self.port)
        c=con.cursor()
        try:
            c.execute(q)
            con.commit()
        except:
            con.rollback()
        con.close()
        
        
    def upload_layer(self,layer,table,schema='public'):
        #only works for points
        uri=QgsDataSourceURI()
        uri.setConnection(self.host, self.port,self.db_name,self.user,self.password)
        
        uri.setWkbType(layer.wkbType())
        uri.setSchema(schema)
        uri.setDataSource(schema, table, 'geom')
        #uri.setSrid(layer.crs().toWkt())
        uri.setSrid('27700')
        uri.setSql("ALTER TABLE "+table+" ALTER COLUMN geom SET DATA TYPE geometry;")
        uri.setWkbType(layer.wkbType())
        #print(uri.uri())
        #piece of #### with no documentation. does not work for anything but points 
        error = QgsVectorLayerImport.importLayer(layer, uri.uri(),"postgres", layer.crs(), False, False)
      #no idea what these arguments are
      #TF gives empty database
        if error[0] != 0:
            return error
            
            
    def drop_table(self,table):
        self.sql('DROP TABLE IF EXISTS '+table)


    def maybe_create_index(self,table='run',schema='public',col='geom',buffer_size=5,Q=False):
        #self.sql('CREATE INDEX IF NOT EXISTS '+table+'_index ON '+table+' using GIST (geom);') does not work for old versions of postgres
        index_name=table+'index'
        q="SELECT 1\n"
        q+="FROM   pg_class c\n"
        q+="JOIN   pg_namespace n ON n.oid = c.relnamespace\n"
        q+="WHERE  c.relname = '"+index_name+"'\n"
        q+="AND    n.nspname = '"+schema+"'"
        r=self.get_query(q)
        q2=""
        if len(r)>0:#index already exists
            return q 
        else:
            q2='CREATE INDEX '+index_name+' ON '+table+' using GIST (geom);'
            if Q:
                return q+'\n\n\n'+q2
            else:
                self.sql(q2)
        

    def secs_query(self,A='run',B='prog',col='sect_label',buffer_size=5,show=False,Q=False):
        q1=self.maybe_create_index(A,Q=Q)
        q2=self.maybe_create_index(B,Q=Q)
        

        query="SELECT DISTINCT ON ("+A+".id) "+A+".id,"+B+"."+col+","+A+".result,"+A+".chainage\n" # only need sec
        query+="FROM "+A+" inner join "+B+" on st_within("+A+".geom,ST_Buffer("+B+".geom,"+str(buffer_size)+",'endcap=flat join=round')) "
        query+="order by "+A+".id,st_distance("+A+".geom,"+B+".geom)"
        #print(q)
        if Q:
            return q1+'\n\n\n'+q2+'\n\n\n'+query

        else:
            return self.get_query(query)
