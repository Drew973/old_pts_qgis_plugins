result=[(8718, u'0900M6/311', 68, 87290), (8719, u'D', 69, 87300), (8720, u'0900M6/311', 70, 87310), (8721, u'0900M6/311', 71, 87320), (8722, u'0900M6/311', 68, 87330), (8723, u'0900M6/311', 66, 87340), (8724, u'D', 70, 87350), (8725, u'0900M6/315', 71, 87360), (8726, u'0900M6/315', 72, 87370), (8727, u'0900M6/315', 64, 87380), (8728, u'0900M6/315', 68, 87390), (8729, u'0900M6/315', 70, 87400), (8730, u'0900M6/315', 36, 87410)]

def get_sec(q,t):
    secs=[]
    last=q[-1]
    #'D' where gap/wheel up
    for row in q:
        sec=row[1]
        if row[2]<25:#result<25 means wheel up
            sec='D'  
        if row[3]-last[3]>10:#gap>10m
            sec='D'
        secs.append(sec)

    #group by section
    r=[]
    last=''
    for s in secs:
        if s!=last:
            r.append({'sec':s,'n':1})
        else:
            r[-1]['n']+=1

        last=s
    
    #ignore where n<amount and not 'D'
    L=[]
    for i in r:
        if i['sec']=='D' or i['n']>t:
            L.append(i['sec'])

    return L

print(get_sec(result,3))
