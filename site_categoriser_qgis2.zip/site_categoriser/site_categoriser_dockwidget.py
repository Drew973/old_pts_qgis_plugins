from  qgis.PyQt import QtGui, uic
from qgis.PyQt.QtCore import pyqtSignal,Qt,QSettings
import os
from qgis.PyQt.QtWidgets import QDockWidget
#from . import pi5,marker
import pi5,marker
from qgis.utils import iface
from qgis.PyQt.QtSql import QSqlDatabase,QSqlTableModel,QSqlQuery


def fixHeaders(path):
    with open(path) as f:
        t=f.read()
    r={'qgsfieldcombobox.h':'qgis.gui','qgsmaplayercombobox.h':'qgis.gui'}
    for i in r:
        t=t.replace(i,r[i])
    with open(path, "w") as f:
        f.write(t)


uiPath=os.path.join(os.path.dirname(__file__), 'site_categoriser_dockwidget_base.ui')
fixHeaders(uiPath)
FORM_CLASS, _ = uic.loadUiType(uiPath)


class site_categoriserDockWidget(QDockWidget,FORM_CLASS):

    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        super(site_categoriserDockWidget, self).__init__(parent)
        self.setupUi(self)
        self.connect_button.clicked.connect(self.connect)
        self.go_to_button.clicked.connect(self.change_sec)
        self.from_map_button.clicked.connect(self.from_map)
        self.cat_combo.addItems(['K','Q1','Q2'])
        self.add_button.clicked.connect(self.add)
        self.delete_button.clicked.connect(self.remove)
        self.checked_box.toggled.connect(self.set_checked)

        self.sec=None
        self.connected=False
        self.connect()

    
    def closeEvent(self, event):
        self.con.disconnect()
        self.closingPlugin.emit()
        event.accept()


    def connect(self):
        self.con=pi5.pi(self.host.text(),self.db_name.text(),self.user.text(),self.password.text(),port=self.port.text())

        #qt database
        self.db = QSqlDatabase.addDatabase("QPSQL",'site_cats')
        self.db.setHostName(self.host.text())
        self.db.setDatabaseName(self.db_name.text())
        self.db.setUserName(self.user.text())
        self.db.setPassword(self.password.text())

        if not self.con.connect():
            self.connected_label.setText('not connected')
            self.connected=False
            iface.messageBar().pushMessage('site_categoriser: could not connect to database',duration=4)
            return

        if not self.db.open():
            self.connected_label.setText('not connected')
            self.connected=False
            iface.messageBar().pushMessage('site_categoriser: could not connect to database',duration=4)
            return

        self.connected_label.setText('connected')
        iface.messageBar().pushMessage('site_categoriser: connected to database',duration=4)
        self.connected=True
        self.jc_model = QSqlTableModel(db=self.db)
        self.setup_jc()
        self.op_model = QSqlTableModel(db=self.db)
        self.setup_op()
        self.ch_tool=marker.chainage_tool(self.from_click_button,self.chainage,self.con)
        
        
    def setup_jc(self):
        self.jc_model.setTable('jc')
        self.jc_model.setEditStrategy(QSqlTableModel.OnFieldChange)       
        self.jc_model.setSort(1,Qt.AscendingOrder)#columns 0 indexed?
        self.jc_model.setFilter("sec=''")
        self.jc_model.select()
        self.jc_table.setModel(self.jc_model)
        self.jc_table.hideColumn(0)
  

    def setup_op(self):
        self.op_model.setTable('op')
        self.op_model.setEditStrategy(QSqlTableModel.OnFieldChange)       
        self.op_model.setFilter("sec=''")
        self.op_model.select()
        self.op_table.setModel(self.op_model)
        self.op_table.hideColumn(0)
        self.op_table.hideColumn(6)
         
        
    def change_sec(self):
        if self.check_section_exists(self.section.text()):
            self.sec=self.section.text()
            #lookup if section checked and set checkbox to this 
            self.checked_box.setChecked(self.con.get_query("select checked from sects where sec=%s limit 1",[self.sec])[0]['checked'])
            #select and zoom to section
            select_section(self.sec,iface.activeLayer())
            self.ch_tool.set_sec(self.sec)
            self.jc_model.setFilter("sec='%s'"%(self.sec))
            self.jc_model.select()
            self.op_model.setFilter("sec='%s'"%(self.sec))
            self.op_model.select()            

    def check_section_exists(self,section):
        if self.connected:
            c=self.con.get_query("select count(sec) from sects where sec=%s",[section])
            if c[0]['count']>0:
                return True
            else:
                iface.messageBar().pushMessage("site_categoriser: section %s does not exist in database"%(section),duration=4)
                return False
        else:
            iface.messageBar().pushMessage("site_categoriser: not connected to database",duration=4)
            return False
            
    def set_checked(self):
        if self.check_section_exists(self.section.text()):
            self.con.sql("update sects set checked=%s where sec=%s",[self.checked_box.isChecked(),self.sec])
        

    def from_map(self):
        sf=iface.activeLayer().selectedFeatures()
            
        if len(sf)>1:
            iface.messageBar().pushMessage("site_categoriser: >1 section selected",duration=4)
            return

        if len(sf)<1:
            iface.messageBar().pushMessage("site_categoriser: no sections selected.",duration=4)
            return

        names=[f.name() for f in sf[0].fields()]
        if not 'sec' in names:
            iface.messageBar().pushMessage("site_categoriser: selected feature has no sec field.",duration=4)
            return
        
        sec=sf[0]['sec']
        self.section.setText(sec)
        self.change_sec()

    def check_layer_box_set(self):
        print(self.layer_box.currentIndex())
       
    def add(self):
        if self.sec is None:
            iface.messageBar().pushMessage("site_categoriser: select a valid section before adding events.",duration=4)
            return
        self.con.sql("select add_to_jc(%s,%s,%s) ",[self.sec,self.chainage.value(),self.cat_combo.currentText()])
        self.update_section()

    def remove(self):
        rows = []
        for index in self.jc_table.selectedIndexes():
            rows.append(index.row())
        rows.sort(reverse=True)
        for row in rows:
            self.jc_table.model().removeRow(row, self.jc_table.rootIndex())
        self.update_section()

    def layer_set(self):
        layer=self.layer_box.currentLayer().name()
        QSettings('pts', 'site_cats').setValue('layer',layer)

    def refresh_layer(self):
        layer=self.op_combobox.currentLayer()
        layer.dataProvider().forceReload()
        layer.triggerRepaint()

    def update_section(self):
        self.con.sql("select update_events(%s);",[self.sec])
        self.con.sql("select process_section(%s);",[self.sec])
        self.con.sql("select process_section_r(%s);",[self.sec])
        self.jc_model.select()
        self.op_model.select()
        
def select_section(section,layer,secField='sec'):
    #Field names in double quotes, string in single quotes
    e="%s IN (%s)" %(double_quote(secField),single_quote(section))#expression looks like "Column_Name" IN ('Value_1', 'Value_2', 'Value_N')
    layer.selectByExpression(e)
    iface.actionZoomToSelected().trigger()#zoom to selected

def single_quote(s):
    return "'%s'"%(s)

def double_quote(s):
    return '"%s"'%(s)  

