class section:
    def __init__(self,sec,secLen):
        self.sec=sec
        self.secLen=secLen
        self.count=1
        self.spacing=10#10m spacing

#returns % coverage
    def coverage(self):
        if self.sec=='D':
            return 100.0#don't have secLen for dummys.
        else:
            return self.spacing*100*self.count/self.secLen




#class for producing section list
class sections:
    def __init__(self):
        self.secs=[]

    # adds dummy if gap then section
    def processSection(self,sec,ch):
        if sec.sec is None:
            self.addDummy()
            self.lastCh=ch
            return
            
        if len(self.secs)==0:
            self.secs.append(sec)
            self.lastCh=ch

        else:
            if ch-self.lastCh>10:#gap>10m
                self.addDummy()

            self.lastCh=ch
            #add section
            if sec.sec!=self.secs[-1].sec:
                self.secs.append(sec)
            else:
                self.secs[-1].count+=1


    def addDummy(self):
        if len(self.secs)==0:
            self.secs.append(section('D',1))
            return
        
        if self.secs[-1].sec!='D':
            self.secs.append(section('D',1))
            
        
    #output section labels
    def secList(self,p):
        last=self.secs[0].sec
        s=[]
        for sec in self.secs:
            sl=sec.sec
            if sec.coverage()<p:
                sl='D'
            if sl!=last:#don't want multiple consecutive dummys?
                s.append(sl)
                last=sl
        return s


    def secList2(self,p):

        #need to add coverages together where section has dummy in middle etc.
        coverages={}
        for sec in self.secs:
            if sec.sec in coverages:
                coverages[sec.sec]+=sec.coverage()
            else:
                coverages.update({sec.sec:sec.coverage()})
            


        
        last=self.secs[0].sec
        s=[]
        for sec in self.secs:
            sl=sec.sec
            if coverages[sl]<p:
                sl='D'
            if sl!=last:#don't want multiple consecutive dummys?
                s.append(sl)
                last=sl
        return s


    def output_dict(self):
        d=[]
        for s in self.secs:
            d.append({'section':s.sec,'count':s.count,'length':s.secLen,'coverage':s.coverage()})
        return d
           
   
