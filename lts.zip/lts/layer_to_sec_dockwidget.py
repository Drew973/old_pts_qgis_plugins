import os
from PyQt4 import QtGui, uic
from PyQt4.QtCore import pyqtSignal
from lts_ui import Ui_ltsDockWidgetBase#ui 'compiled' to python via 
from qgis.utils import iface
from qgis.gui import QgsFieldProxyModel,QgsMapLayerProxyModel
from os.path import expanduser

from sections2 import sections#,section

class ltsDockWidget(QtGui.QDockWidget,Ui_ltsDockWidgetBase):

    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        """Constructor."""        
        super(ltsDockWidget, self).__init__(parent)
        self.setupUi(self)

        self.layerBox.setFilters(QgsMapLayerProxyModel.PointLayer) 
        self.layerBox.layerChanged.connect(self.layerChange)
        
        self.chainageBox.setFilters(QgsFieldProxyModel.Numeric)
        self.sectionBox.setFilters(QgsFieldProxyModel.String)
        self.xpsBox.setFilters(QgsFieldProxyModel.String)
        self.secLenBox.setFilters(QgsFieldProxyModel.Numeric)
        ###############
        
        self.layerChange(self.layerBox.currentLayer())#triggers layerChanged 
        self.goButton.clicked.connect(self.process)


    def layerChange(self,layer):
        self.chainageBox.setLayer(layer)
        self.sectionBox.setLayer(layer)
        self.xpsBox.setLayer(layer)
        self.secLenBox.setLayer(layer)

        self.chainageBox.setCurrentIndex(self.chainageBox.findText('chainage'))#set to chainage if there, else 1st
        self.sectionBox.setCurrentIndex(self.sectionBox.findText('sec'))#set to sec if there
        self.xpsBox.setCurrentIndex(self.xpsBox.findText('xps'))#set to xps if there
        self.secLenBox.setCurrentIndex(self.secLenBox.findText('sec_length'))#set to sec_length if there
       
        
    def closeEvent(self,event):
        self.closingPlugin.emit()
        event.accept()


    def process(self):
        chCol=self.chainageBox.currentField()
        secCol=self.sectionBox.currentField()
        xpsCol=self.xpsBox.currentField()
        secLenCol=self.secLenBox.currentField()

        if chCol=='':
            iface.messageBar().pushMessage("layer to sec error: Chainage field not set ",duration=5)
            return
        
        if secCol=='':
            iface.messageBar().pushMessage("layer to sec error: Section field not set ",duration=5)
            return

        if secLenCol=='':
            iface.messageBar().pushMessage("layer to sec error: Section Length field not set ",duration=5)
            return

        md=expanduser('~\\Documents')#path to user's documents folder
        path=QtGui.QFileDialog.getSaveFileName(self, 'Save File',filter='.sec',directory=md)
        if path=='':
            return

        s=sections()
        for f in self.layerBox.currentLayer().getFeatures():
            s.add(f[secCol],f[secLenCol],f[chCol])#sec,len,ch

        self.writeFile(path,s.secList(self.percentageBox.value()))


    def writeFile(self,path,text):
        if isinstance(text,list):
            text=','.join(text)

        try:
            with open(path,'w') as f:
                f.write(text)

            iface.messageBar().pushMessage("Wrote .sec file to "+path,duration=3)
            
        except:
            iface.messageBar().pushMessage("layer to sec error: error writing file ",duration=5)



  



