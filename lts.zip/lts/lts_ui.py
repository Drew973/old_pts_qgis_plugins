# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\drew.bennett\.qgis2\python\plugins\lts\layer_to_sec_dockwidget_base.ui'
#
# Created: Wed May 22 15:47:17 2019
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ltsDockWidgetBase(object):
    def setupUi(self, ltsDockWidgetBase):
        ltsDockWidgetBase.setObjectName(_fromUtf8("ltsDockWidgetBase"))
        ltsDockWidgetBase.resize(323, 306)
        self.dockWidgetContents = QtGui.QWidget()
        self.dockWidgetContents.setObjectName(_fromUtf8("dockWidgetContents"))
        self.tabWidget = QtGui.QTabWidget(self.dockWidgetContents)
        self.tabWidget.setGeometry(QtCore.QRect(0, 0, 311, 271))
        self.tabWidget.setObjectName(_fromUtf8("tabWidget"))
        self.tab_2 = QtGui.QWidget()
        self.tab_2.setObjectName(_fromUtf8("tab_2"))
        self.splitter_2 = QtGui.QSplitter(self.tab_2)
        self.splitter_2.setGeometry(QtCore.QRect(10, 130, 231, 20))
        self.splitter_2.setOrientation(QtCore.Qt.Horizontal)
        self.splitter_2.setObjectName(_fromUtf8("splitter_2"))
        self.label_4 = QtGui.QLabel(self.splitter_2)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.secLenBox = QgsFieldComboBox(self.splitter_2)
        self.secLenBox.setObjectName(_fromUtf8("secLenBox"))
        self.splitter_6 = QtGui.QSplitter(self.tab_2)
        self.splitter_6.setGeometry(QtCore.QRect(10, 40, 231, 20))
        self.splitter_6.setOrientation(QtCore.Qt.Horizontal)
        self.splitter_6.setObjectName(_fromUtf8("splitter_6"))
        self.label_6 = QtGui.QLabel(self.splitter_6)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.chainageBox = QgsFieldComboBox(self.splitter_6)
        self.chainageBox.setObjectName(_fromUtf8("chainageBox"))
        self.splitter_3 = QtGui.QSplitter(self.tab_2)
        self.splitter_3.setGeometry(QtCore.QRect(10, 100, 231, 20))
        self.splitter_3.setOrientation(QtCore.Qt.Horizontal)
        self.splitter_3.setObjectName(_fromUtf8("splitter_3"))
        self.label_3 = QtGui.QLabel(self.splitter_3)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.xpsBox = QgsFieldComboBox(self.splitter_3)
        self.xpsBox.setObjectName(_fromUtf8("xpsBox"))
        self.splitter = QtGui.QSplitter(self.tab_2)
        self.splitter.setGeometry(QtCore.QRect(10, 160, 151, 20))
        self.splitter.setOrientation(QtCore.Qt.Horizontal)
        self.splitter.setObjectName(_fromUtf8("splitter"))
        self.label_5 = QtGui.QLabel(self.splitter)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.percentageBox = QtGui.QDoubleSpinBox(self.splitter)
        self.percentageBox.setDecimals(1)
        self.percentageBox.setMaximum(100.0)
        self.percentageBox.setProperty("value", 80.0)
        self.percentageBox.setObjectName(_fromUtf8("percentageBox"))
        self.goButton = QtGui.QPushButton(self.tab_2)
        self.goButton.setGeometry(QtCore.QRect(10, 190, 51, 23))
        self.goButton.setObjectName(_fromUtf8("goButton"))
        self.splitter_5 = QtGui.QSplitter(self.tab_2)
        self.splitter_5.setGeometry(QtCore.QRect(10, 10, 231, 20))
        self.splitter_5.setOrientation(QtCore.Qt.Horizontal)
        self.splitter_5.setObjectName(_fromUtf8("splitter_5"))
        self.label = QtGui.QLabel(self.splitter_5)
        self.label.setObjectName(_fromUtf8("label"))
        self.layerBox = QgsMapLayerComboBox(self.splitter_5)
        self.layerBox.setObjectName(_fromUtf8("layerBox"))
        self.splitter_4 = QtGui.QSplitter(self.tab_2)
        self.splitter_4.setGeometry(QtCore.QRect(10, 70, 231, 20))
        self.splitter_4.setOrientation(QtCore.Qt.Horizontal)
        self.splitter_4.setObjectName(_fromUtf8("splitter_4"))
        self.label_2 = QtGui.QLabel(self.splitter_4)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.sectionBox = QgsFieldComboBox(self.splitter_4)
        self.sectionBox.setObjectName(_fromUtf8("sectionBox"))
        self.tabWidget.addTab(self.tab_2, _fromUtf8(""))
        self.tab = QtGui.QWidget()
        self.tab.setObjectName(_fromUtf8("tab"))
        self.textBrowser = QtGui.QTextBrowser(self.tab)
        self.textBrowser.setGeometry(QtCore.QRect(10, 0, 291, 251))
        self.textBrowser.setObjectName(_fromUtf8("textBrowser"))
        self.tabWidget.addTab(self.tab, _fromUtf8(""))
        self.Settings = QtGui.QWidget()
        self.Settings.setObjectName(_fromUtf8("Settings"))
        self.gapSize = QtGui.QDoubleSpinBox(self.Settings)
        self.gapSize.setGeometry(QtCore.QRect(150, 20, 62, 22))
        self.gapSize.setProperty("value", 11.0)
        self.gapSize.setObjectName(_fromUtf8("gapSize"))
        self.label_7 = QtGui.QLabel(self.Settings)
        self.label_7.setGeometry(QtCore.QRect(10, 20, 131, 16))
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.tabWidget.addTab(self.Settings, _fromUtf8(""))
        ltsDockWidgetBase.setWidget(self.dockWidgetContents)

        self.retranslateUi(ltsDockWidgetBase)
        self.tabWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(ltsDockWidgetBase)

    def retranslateUi(self, ltsDockWidgetBase):
        ltsDockWidgetBase.setWindowTitle(_translate("ltsDockWidgetBase", "layer_to_sec", None))
        self.label_4.setText(_translate("ltsDockWidgetBase", "Section length field", None))
        self.secLenBox.setToolTip(_translate("ltsDockWidgetBase", "<html><head/><body><p>Field with section length. Must be Numeric.</p></body></html>", None))
        self.label_6.setText(_translate("ltsDockWidgetBase", "Chainage field", None))
        self.chainageBox.setToolTip(_translate("ltsDockWidgetBase", "<html><head/><body><p>Field with Chainage. Must be Numeric.</p></body></html>", None))
        self.label_3.setText(_translate("ltsDockWidgetBase", "XPS field", None))
        self.xpsBox.setToolTip(_translate("ltsDockWidgetBase", "<html><head/><body><p>Field with XPS code. Must be text.</p></body></html>", None))
        self.label_5.setText(_translate("ltsDockWidgetBase", "Min % coverage", None))
        self.percentageBox.setToolTip(_translate("ltsDockWidgetBase", "<html><head/><body><p>Only sections with coverage  &gt;this count as valid.</p></body></html>", None))
        self.goButton.setToolTip(_translate("ltsDockWidgetBase", "<html><head/><body><p>Opens save dialog then makes the .sec file.</p></body></html>", None))
        self.goButton.setText(_translate("ltsDockWidgetBase", "Go", None))
        self.label.setText(_translate("ltsDockWidgetBase", "Layer", None))
        self.layerBox.setToolTip(_translate("ltsDockWidgetBase", "<html><head/><body><p>Layer to make .sec from. Should have Point geometry.</p></body></html>", None))
        self.label_2.setText(_translate("ltsDockWidgetBase", "Section field", None))
        self.sectionBox.setToolTip(_translate("ltsDockWidgetBase", "<html><head/><body><p>Field with section. Must be Text.</p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), _translate("ltsDockWidgetBase", "Make .sec", None))
        self.textBrowser.setHtml(_translate("ltsDockWidgetBase", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">Makes .sec file from selected layer.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">This is a text file listing the sections where the % coverage is &gt;[percentage].</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">Adds \'D\' where section unknown, insufficient coverage of gap&gt;[size].</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">The layer needs fields with the following data:</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">-chainage:numeric (integer or float)</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">-section: text (string)</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">-xps:text (string)</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">-section length:numeric (integer or float)</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">Names of these need to be selected.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">Only fields with the correct types are shown.</span></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), _translate("ltsDockWidgetBase", "Help", None))
        self.label_7.setText(_translate("ltsDockWidgetBase", "Add dummies where gap> ", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.Settings), _translate("ltsDockWidgetBase", "Settings", None))

from qgis.gui import QgsFieldComboBox, QgsMapLayerComboBox
