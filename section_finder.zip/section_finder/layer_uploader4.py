import psycopg2
from psycopg2.extras import DictCursor
from PyQt4.QtCore import QPyNullVariant

from pi4 import pi

class layer_uploader(pi):    
    def upload(self,layer,table_name,fields='all',fid=True,geom=True):
        self.layer=layer
        self.scrid=self.layer.crs().postgisSrid()
        self.fid=fid
        self.geom=geom
        self.table_name=table_name
        self.get_cols(fields)

        self.text='drop table if exists %s;\n'%(self.table_name)
        self.text+=self.create_table()
  
        #self.sql not used because don't want to be opening and closing connection for each feature


        if self.geom:
            self.text+="select AddGeometryColumn('%s','geom',%s,'%s',2);\n"%(table_name,str(self.scrid),geom_type(layer))
            self.cols.append('geom')

        self.set_irq1()#first part of insert query

        
        for f in self.layer.getFeatures():
            self.text+=self.insert_feat_query(f)
            

        con = psycopg2.connect(host=self.host,dbname=self.db_name,user=self.user,password=self.password,port=self.port)
        c=con.cursor(cursor_factory=DictCursor)

        c.execute(self.text)
        
        con.commit()
        
        con.close()
          
    def set_irq1(self):
        self.irq1="insert into %s (%s) " %(self.table_name,','.join(self.cols))
        
        
    def insert_feat_query(self,feat):
        vals=[]
        for col in self.cols:
            val=None
            
            if col=='fid':
                val=feat.id()
                
            if col=='geom':
                val="ST_GeomFromText('%s',%s)"%(feat.geometry().exportToWkt(),self.scrid)
            
            if val is None:
                val=feat[col]
                
            if isinstance(val,QPyNullVariant):
                val=None
                
            vals.append(str(val)) 
        return self.irq1+" values (%s);\n"%(','.join(vals))
    
    
    def get_cols(self,fields):
        layer_fields=[f.name() for f in self.layer.fields()]
       
        if fields=='all':
            fields=layer_fields
    
    #check all fields are in layer
        for name in fields:
            if not name in layer_fields:
                raise ValueError('Field '+name+' not in layer' )
        
        self.cols=[]
        self.types=[]
        cols=[]#{name:type}
        
        if self.fid:
            self.cols.append('fid')
            self.types.append('int')
            

        for f in self.layer.fields():
            if f.name() in fields:
                self.cols.append(f.name())
                self.types.append(to_postgres_type(f))
   
#drops table if exists then creates.
    def create_table(self):

        
        ct=[]
        for i,v in enumerate(self.cols):
            ct.append(v+' '+self.types[i])
        ct=','.join(ct)
        
        return "create table %s (%s);\n" %(self.table_name,ct)
        #self.sql(q)

          
def to_postgres_type(field):
    t={2:'int',6:'float',10:'varchar',14:'date'}
    return t[field.type()]

    
def geom_type(layer):
    #types={0:'WKBUnknown',1: 'WKBPoint',2:'WKBLineString', 3:'WKBPolygon', 4:'WKBMultiPoint',5:'WKBMultiLineString',6:'WKBMultiPolygon',7:'WKBNoGeometry',8:'WKBPoint25D',9: 'WKBLineString25D',10:'WKBPolygon25D',11:'WKBMultiPoint25D',12:'WKBMultiLineString25D',13:'WKBMultiPolygon25D'}

    types={0:'Unknown',1:'Point',2:'LineString',3:'Polygon',4:'MultiPoint',5:'MultiLineString',6:'MultiPolygon',7:'NoGeometry',8:'Point25D',9: 'LineString25D',10:'Polygon25D',11:'MultiPoint25D',12:'MultiLineString25D',13:'MultiPolygon25D'}
    t=layer.wkbType()
    if t in types:
        return types[t]    


