from qgis.core import QgsVectorLayer,QgsField,QgsFeature,QgsMapLayerRegistry,QgsField,QgsWKBTypes
from PyQt4.QtCore import QVariant

class fid:
    def __init__(self,row):
        self.fid=row['fid']
        self.sec=''
        self.opts=[row['sec']]
        self.rows=[row]
        
    def get_row(self):
        if self.sec!='':
            return self.rows[self.opts.index(self.sec)]


    def nearest(self):
        if self.sec=='':
            self.set_sec(self.opts[0],'nearest')


    def add_opt(self,row):
        self.rows.append(row)
        self.opts.append(row['sec'])

        
    def set_sec(self,sec,method):
        if not sec in self.opts:
            raise ValueError('section not in options')
        self.sec=sec
        self.method=method


    #where only 1 option assign that
    def only_option(self):
        if len(self.opts)==1:
            self.set_sec(self.opts[0],'only option')


    #set to sec if in opts
    def last(self,sec,m=''):
        if self.sec=='':
            if sec in self.opts:
                self.set_sec(sec,m)          


sepstr=';'

class results_processor:
    def __init__(self,results):       
        self.fids=[]

        
        for i,row in enumerate(results):#fid,sec,xps,sec_length, in buffer and correct direction, sorted by fid,distance    
            if i==0:
                self.fids.append(fid(row))

            else:
                if  row['fid']==self.fids[-1].fid:
                    self.fids[-1].add_opt(row)
                else:
                    self.fids.append(fid(row))
        for f in self.fids:
            f.only_option()
                
            
#uses nearest section to points with unknown section
    def nearest(self):
        for f in self.fids:
            if f.sec=='':
                f.nearest()

                
#go through sections assigning last section where in opts and section unknown
    def last_sec(self,reverse=False):        
        if reverse:
            self.fids.reverse()
            method='next'
        else:
            method='last'
            
        last=''
        for f in self.fids:
            f.last(last,method)
            if f.sec!='':
                last=f.sec

        if reverse:#so same way around
            self.fids.reverse()
       

    def significant_sections(self,t=1):
        counts={}
        for f in self.fids:
            if f.sec in counts:
                counts[f.sec]+=1
            else:
                counts.update({f.sec:1})

        sig=[]
        for c in counts:
            if counts[c]>=t:
                sig.append(c)

        for f in self.fids:
            if f.sec=='':
                m=[]
                for o in f.opts:
                    if o in sig:
                        m.append(o)
                if len(m)==1:
                    f.set_sec(m[0],'significant sections')

        
    def add_to_layer(self,layer,method=False,opts=False):#col=new field
        fields=[QgsField('sec',QVariant.String),QgsField('xps',QVariant.String),QgsField('sec_length',QVariant.Double)]

        if method:
            fields.append(QgsField('method',QVariant.String))

        if opts:
            fields.append(QgsField('options',QVariant.String))
             
        p=layer.dataProvider()
        p.addAttributes(fields)
        layer.commitChanges()
        layer.updateFields()
        m=p.fieldNameMap()
     
        for f in self.fids:
            r=f.get_row()
            if not r is None:
                
                d={m['sec'] : r['sec'],m['xps']:r['xps'],m['sec_length']:r['sec_length']}

                if method:
                    d.update({m['method']:f.method})

                if opts:
                    d.update({m['options']:','.join(f.opts)})
                
            p.changeAttributeValues({r['fid'] : d})####{id:{index:value}}
        p.updateExtents()#updates attribute table?


def copy_to_memory(layer,name='new_layer'):
    lp=layer.dataProvider()
    geom_type=QgsWKBTypes.displayString(int(layer.wkbType()))#geometry type as string. 
    mem_layer = QgsVectorLayer(geom_type+"?crs="+layer.crs().authid(), name, "memory")
    fields=lp.fields().toList()
    p = mem_layer.dataProvider()
    p.addAttributes(fields)
    mem_layer.updateFields()

    feats=[]
    for feat in layer.getFeatures():
        feats.append(feat)
        feats[-1].setGeometry(feat.geometry())
        
    p.addFeatures(feats)
    mem_layer.updateExtents()

    QgsMapLayerRegistry.instance().addMapLayer(mem_layer)
    return mem_layer
