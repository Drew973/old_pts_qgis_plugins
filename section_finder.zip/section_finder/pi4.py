
import psycopg2
from psycopg2.extras import DictCursor
from os import path as osp


class pi:
     
    def __init__(self,host,db_name,user,password='',port='5432'):
        self.host=host
        self.db_name=db_name
        self.user=user
        self.password=password
        self.port=port
        

    def test(self):
        try:
            con = psycopg2.connect(host=self.host,dbname=self.db_name,user=self.user,password=self.password,port=self.port)
            con.close()
            return True
        except:
            return False


    def get_query(self,q,args=[]):
        con = psycopg2.connect(host=self.host,dbname=self.db_name,user=self.user,password=self.password,port=self.port)
        c=con.cursor(cursor_factory=DictCursor)
        if args!=[]:
            c.execute(q,args)
        else:
            c.execute(q)
        r=c.fetchall()
        if r is None:
            r=[]
        con.close()
        return r
        

    def list_tables(self,schema='public',Q=False):
        q="SELECT table_name\n"
        q+="FROM information_schema.tables\n"
        q+="WHERE table_schema='"+schema+"'\n"
        q+="ORDER BY table_schema,table_name;"
        if Q:
            return q
        else:
            L=self.get_query(q)
            return [row[0] for row in L]

    def list_cols(self,table,schema='public',Q=False,t='character varying'):
        q="SELECT column_name FROM information_schema.columns\n"
        q+="WHERE table_schema = '"+schema+"'\n"
        q+="AND table_name   = '"+table+"'"
        q+="AND data_type='"+t+"'"
        if Q:
            return q
        else:
            L=self.get_query(q)
            return [row[0] for row in L]

  
    def sql(self,q,args=[]):
        con = psycopg2.connect(host=self.host,dbname=self.db_name,user=self.user,password=self.password,port=self.port)
        c=con.cursor(cursor_factory=DictCursor)
        if args!=[]:
            c.execute(q,args)
        else:
            c.execute(q)
        con.commit()
        con.close()
        return True

    def run_script(self,path,relpath=True):
        if relpath:
            path=full_path(path)
        with open (path,'r') as f:
            q=f.read()
            print q
            self.sql(q)
            
    def drop_table(self,table):
        self.sql('DROP TABLE IF EXISTS '+table)


    def maybe_create_index(self,table='run',schema='public',col='geom'):
        #self.sql('CREATE INDEX IF NOT EXISTS '+table+'_index ON '+table+' using GIST (geom);') does not work for old versions of postgres
        index_name=table+'index'
        q="SELECT 1\n"
        q+="FROM   pg_class c\n"
        q+="JOIN   pg_namespace n ON n.oid = c.relnamespace\n"
        q+="WHERE  c.relname = '"+index_name+"'\n"
        q+="AND    n.nspname = '"+schema+"'"
        r=self.get_query(q)
        
        if len(r)>0:#index already exists
            return ''
        
        else:
            q='CREATE INDEX %s ON %s using GIST (%s);'%(index_name,table,col)
            self.sql(q)

        
def full_path(p):
    folder=osp.dirname(osp.realpath(__file__))
    return osp.join(folder,p)

