import os


def fix_headers(path):
    with open(path) as f:
        t=f.read()

    r={'qgsfieldcombobox.h':'qgis.gui','qgsmaplayercombobox.h':'qgis.gui'}
    for i in r:
        t=t.replace(i,r[i])


    with open(path, "w") as f:
        f.write(t)


#ui=.ui file
#py=.py file to be made
        
def compile_ui(ui,py):
    command='pyuic4 '+ui+' -o '+py
    print('run this in OSGeo4W shell:')
    print(command)



folder=r'C:\Users\drew.bennett\.qgis2\python\plugins\section_finder'
ui='section_finder_dockwidget_base.ui'
ui_path=os.path.join(folder,ui)

to='section_finder_ui.py'    
to_path=os.path.join(folder,to)

if os.path.isfile(to_path):
    os.remove(to_path)
    print('deleted '+to_path)

fix_headers(ui)
compile_ui(ui_path,to_path)




