drop table if exists SL;
create table SL(
sec varchar,
xps varchar,
sec_length float,
dual_name varchar,
geom geometry
	
);

DROP FUNCTION if exists fill_SL();
CREATE OR REPLACE FUNCTION fill_sl() 
RETURNS int AS $$
		declare 
		r record;
        BEGIN		
			FOR r in select sect_label,dual_name,sec_length,geom from prog where dual_name like '%Two Way%'
			LOOP 
				INSERT INTO sl
					(sec,xps,sec_length,dual_name,geom)
					VALUES
					(r.sect_label,'CL',r.sec_length,r.dual_name,ST_LineMerge(r.geom));
				
				INSERT INTO sl
					(sec,xps,sec_length,dual_name,geom)
					VALUES
					(r.sect_label,'CR',r.sec_length,r.dual_name,ST_REVERSE(ST_LineMerge(r.geom)));				
													  
			END LOOP;
									  
			FOR r in select sect_label,dual_name,sec_length,geom from prog where dual_name not like '%Two Way%'
			LOOP 
				INSERT INTO sl
					(sec,xps,sec_length,dual_name,geom)
					VALUES
					(r.sect_label,'CL',r.sec_length,r.dual_name,ST_LineMerge(r.geom));									  
			END LOOP;		
        	return 1;
        END;			
		
$$ LANGUAGE plpgsql;		


								  
select fill_SL();												  
														  

drop table if exists SL3;

create table SL3(
sec varchar,
xps varchar,
sec_length float,
vector geometry(Linestring,27700),
wkt_vector varchar,
buffer geometry(Polygon,27700),
sn int,
en int
);



DROP FUNCTION if exists fill_SL3();
CREATE OR REPLACE FUNCTION fill_SL3() 
RETURNS int AS $$
		declare 
		r record;
		pt geometry;
		last_pt geometry;
		co int;
		n int;
		vector geometry;
		buffer geometry;
		
		
        BEGIN		
			FOR r in select sec,xps,sec_length,geom from SL 
			
			LOOP 
				co=0;
				n=ST_NPoints(r.geom)-1;
																			 
				for pt in select geom from ST_DumpPoints(ST_LineMerge(r.geom))
					loop
					--set last_pt to 1st point		
						if co=0 then
						last_pt=pt;						  								  
						end if;
																	  
						vector=ST_MakeLine(last_pt,pt);	  
						if co=0 or co=n then
							buffer=ST_Buffer(vector,7,'endcap=flat');--flat buffers at ends of section.
						else
							buffer=ST_Buffer(vector,7,'endcap=square');	-- larger ends within section. Doing this way avoids gaps within section.
						end if;
																	  
						INSERT INTO sl3(sec,xps,sec_length,vector,buffer)											  													  
						VALUES	(r.sec,r.xps,r.sec_length,vector,buffer);	
																	  
					last_pt=pt;
					co=co+1;												  
					end loop;
			END LOOP;		
        	return co;
        END;			
		
$$ LANGUAGE plpgsql;
															  
																	  
select fill_SL3();																	  																	  
CREATE INDEX sl3_index ON SL3 using GIST(vector);


CREATE OR REPLACE FUNCTION run_points_to_vectors() 
RETURNS int AS $$
		declare 
		r record;
		last_pt geometry;
		vect geometry;
		co int=0;
		
        BEGIN		
			FOR r in select fid,geom from run
			LOOP 
				if co=0 then
				last_pt=r.geom;
				
				end if;
					update run set vector=ST_MakeLine(last_pt,r.geom) where fid=r.fid;
					co=co+1;												  
					last_pt=r.geom;
			  
			END LOOP;		
        	return 1;
        END;			
		
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION dot_prod(g1 geometry,g2 geometry) 
RETURNS float AS $$		
        BEGIN
			return(ST_X(ST_EndPoint(g1))-st_X(st_StartPoint(g1)))*(ST_X(ST_EndPoint(g2))-st_X(st_StartPoint(g2)))+(ST_Y(ST_EndPoint(g1))-st_Y(st_StartPoint(g1)))*(ST_Y(ST_EndPoint(g2))-st_Y(st_StartPoint(g2)));
        END;			
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION cos_angle(g1 geometry,g2 geometry) 
RETURNS float AS $$		
		declare 
			l1 float=ST_Length(g1);
			l2 float=ST_Length(g2);
		
		BEGIN
		
		if l1=0 or l2=0 then
			return 0.0;
		end if;
		
		return dot_prod(g1,g2)/(l1*l2);
		
        END;			
$$ LANGUAGE plpgsql;	
