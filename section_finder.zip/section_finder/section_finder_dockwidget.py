#import os

from PyQt4 import QtGui, uic
from PyQt4.QtCore import pyqtSignal#,pyqtSlot

from qgis.gui import QgsMapLayerProxyModel



import layer_uploader4 as pi
from PyQt4.QtCore import QSettings#,QVariant
#from qgis.core import QgsMapLayerRegistry,QgsWKBTypes#,QgsVectorLayer,QgsField #,QgsProject
from qgis.utils import iface

import result_processing5 as rp
#import layer_functions as lf
#import uploading_layer as ul


#fix .ui file. Fixes where .ui generated incorrectly for QGIS custom widgets.

from section_finder_ui import Ui_section_finder


class section_finderDockWidget(QtGui.QDockWidget, Ui_section_finder):
    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        """Constructor."""
        super(section_finderDockWidget, self).__init__(parent)
        self.setupUi(self)
        
        self.layer_box.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.table.activated.connect(self.table_set)

        self.connect.clicked.connect(self.con)
        
        self.go.clicked.connect(self.process)
        self.go.clicked.connect(self.save_config)

        self.cols={}
        self.load_config()
        
        self.con()


    def load_config(self):
        settings=QSettings('pts', 'section_finder')
        self.port.setText(settings.value('port'))
        self.host.setText(settings.value('host'))
        self.db_name.setText(settings.value('db_name'))
        self.user.setText(settings.value('user'))
        self.password.setText(settings.value('password'))
        self.con()


    def save_config(self):
        settings=QSettings('pts', 'section_finder')
        settings.setValue('port',self.port.text())
        settings.setValue('host',self.host.text())
        settings.setValue('db_name',self.db_name.text())
        settings.setValue('user',self.user.text())
        settings.setValue('password',self.password.text())

        
    def con(self):
        self.connection=pi.layer_uploader(self.host.text(),self.db_name.text(),self.user.text(),self.password.text(),port=self.port.text())
        if self.connection.test():
            self.save_config()
            self.connected_label.setText('Connected')
            self.refresh_tables()

            #move to table from saved settings if available
            i=self.table.findText(QSettings('pts', 'section_finder').value('table'))#-1 if not found
            self.table.setCurrentIndex(i)#-1 sets to nothing        
            return True
        else:
            self.connected_label.setText('Not connected')
            self.table.clear()
            return False

    def refresh_tables(self):
        t=self.connection.list_tables()
        self.table.clear()
        self.table.addItems(t)    


#causes column_change            
    def table_set(self):
        QSettings('pts', 'section_finder').setValue('table',self.table.currentText())

        
    def column_change(self):
        table=self.table.currentText()
        c=self.column.currentText()
        
        if table in self.cols:
            self.cols[table]=c
        else:
            self.cols.update({table:c})

        QSettings('pts', 'section_finder').setValue('cols',self.cols)
        
    
    def process(self):
        #error message if not connected
        if self.connected_label.text()=='Not connected':
            self.error('Not connected to database')
            return


        if self.upload_layer():
            if self.query_database():
                if self.process_results():
                    self.status.setText('Done.')
                    self.repaint()
         

    def upload_layer(self):
        self.status.setText('Uploading layer to database...')
        self.repaint()
        self.layer=rp.copy_to_memory(self.layer_box.currentLayer(),self.new_name.text())#make new layer before uploading-fids change
        self.connection.upload(layer=self.layer,fields=[],table_name='run')
        self.connection.sql("select AddGeometryColumn(%s,'vector',%s,'Linestring',2);",[self.connection.table_name,str(self.connection.scrid)])
        self.connection.sql("select run_points_to_vectors();")
        self.connection.maybe_create_index('run')
            
        try:
            return True
          
        except:
            self.error('Error uploading layer')
            return False


    def query_database(self):
        self.status.setText('Querying database...')
        self.repaint()

        q="select fid,sec,xps,sec_length from run inner join sl3 on ST_WITHIN(run.geom,sl3.buffer) and dot_prod(sl3.vector,run.vector)>=0 and cos_angle(sl3.vector,run.vector)>0.94 order by fid,st_distance(run.geom,sl3.vector);"

        #angle<20 degrees
        
        self.q=self.connection.get_query(q)
        try:                         
            #drop table        
            try:
                self.connection.drop_table('run')
            except:
                pass
            return True                  
        except:
            self.error('Error querying database. Is table correct?')
            return False


    def process_results(self):
        self.status.setText('Processing results...')
        self.repaint()

        p=rp.results_processor(self.q)

        if self.significant.isChecked():
            p.significant_sections(self.significant_spinBox.value())

        if self.last.isChecked():
            p.last_sec()

        if self.next.isChecked():
            p.last_sec(reverse=True)
            
        if self.nearest.isChecked():
            p.nearest()

        p.add_to_layer(self.layer,method=self.add_method.isChecked(),opts=self.add_opts.isChecked())#copy layer and add section,xps,sec_len
        return True


    def error(self,e,set_text=True):
        self.message(e)
        if set_text:
            self.status.setText('Quit with error')
            self.repaint()

        
    def message(self,e,t=20):
        bar=iface.messageBar()
        bar.pushMessage("section_finder error",e,duration=t)


    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

       
            
        






            
