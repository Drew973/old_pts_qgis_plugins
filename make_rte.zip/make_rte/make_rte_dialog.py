#import os

from PyQt4 import QtGui, uic

import sys, os#,platform
from librte import hapms_make_rte
from PyQt4.QtCore import *
from PyQt4.QtGui import *

from os import path,listdir

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    path.dirname(__file__), 'make_rte_dialog_base.ui'))


class make_rteDialog(QtGui.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(make_rteDialog, self).__init__(parent)
        self.setupUi(self)

        self.bulkRTEButton.clicked.connect(self.bulkRTE)

        
        
    def procSEC(self, f):
        secs = []
        with open(f, 'r') as secfile:
          for row in secfile:
            secs.append(row.strip())
        return secs

    
        
    def bulkRTE(self):
        md=path.expanduser('~\\Documents')#path to users my documents folder
        folder = QFileDialog.getExistingDirectory(self, "RCDs folder",md, QFileDialog.ShowDirsOnly)
        
        if folder!='':
            files = [f for f in listdir(folder) if f.endswith('.sec')] 

            if files==[]:
                QMessageBox.information(self, "error",'no .sec files found in '+folder)
                return


            for f in files:
              #try:
                route_id = f.split('.')[0] + '.rte'
                rte_file = folder + '/' + f
                
                secs = self.procSEC(rte_file)
                
                rte = hapms_make_rte(routeid = route_id,\
                                db = str(self.databaseEdit.text()),\
                                host = str(self.hostEdit.text()),\
                                user = str(self.userEdit.text()),\
                                dir_f= not self.reversed.isChecked(),\
                                secs=secs)
                m=rte.make()
                if m==True:
                    rte.save(folder + '/' + route_id)
                
                else:
                    QMessageBox.information(self, "error in "+f,m)

            QMessageBox.information(self, "RCD files created","RCDs succesfully created")         
