#!/usr/bin/python
#hapms_route_builder
#load csv file with sections and create HA HAPMS route file RTE

import platform
import psycopg2
import psycopg2.extras


class hapms_make_rte():
    
    def __init__(self, routeid, secs, db, host, user, passwd='', dir_f=True):
        self.routeid = routeid
        self.secs = secs
        self.dir_f = dir_f
        
        self.rows = [] #store all the output rows
        self.__nsec = 0    #count survey sections including dummy sections
        
        #RTE data structures
        #route header data, single record
        self.header = """ROUTE{file_format_ver:8}{route_ident:50}{n_surv_lanes:5d}"""
        
        #repeated for each survey lane as defined in header sorted in sequence through the route
        #a dummy survey lane requires only a start reference marker label. other data items may be
        #provided (if known) or may be blank / zero as appropriate
        #lane direction indicator will be the same as, or opposite to, section referencing direction
        #indicator defined in the corresponding section record
        self.surv_line = """{sec:<30}{surv_dir:<2}{lname:<20}{start_ch:>11.3f}{end_ch:>11.3f}{start_marker:<20}{start_marker_x:>11.3f}{start_marker_y:11.3f}"""
        
        #end of route reference, single record
        self.end_route = """{end_marker:20}{end_marker_x:11.3f}{end_marker_y:11.3f}"""
        
        #repeated for each (non-dumy) section referred to in records, sorted alphabetically by section label
        self.sect = """{sec_label:30}{sec_start_date:11}{sec_end_date:11}{sec_l:11.3f}{sec_dir:2}{sec_funct:4}"""

        #PTS DB sql
        #connect to db
        self.con = psycopg2.connect(database=db, host=host, user=user, password=passwd)
        #return the db results as dict
        self.cur = self.con.cursor(cursor_factory = psycopg2.extras.DictCursor)
                                                    
        self.sql_sect = """SELECT sect_label as sec_label, 
                        to_char(start_date, 'DD-Mon-YYYY') as sec_start_date, 
                        '' as sec_end_date,
                         sec_length as sec_l, 
                         direc_code as sec_dir, 
                         funct_name as sec_funct
                         FROM prog
                         WHERE sect_label=%s"""
                                             
        self.sql_end_route = """SELECT lrp_code as end_marker,
                             x as end_marker_x,
                             y as end_marker_y
                             FROM lrp19
                             WHERE lrp19.ch=lrp19.sec_l and lrp19.sec=%s"""
                                                            
        self.sql_end_route_r = """SELECT lrp_code as end_marker,
                                x as end_marker_x,
                                y as end_marker_y
                                FROM lrp19
                                WHERE lrp19.ch=0 and lrp19.sec=%s"""
                                                                    
        self.sql_surv_line = """SELECT sec, 
			                     direction as surv_dir,
			                     'Lane 1' as lname, 
			                     0::float as start_ch, 
			                     sec_l as end_ch, 
			                     lrp_code as start_marker, 
			                     x as start_marker_x, 
			                     y as start_marker_y
            			        FROM lrp19
            			        WHERE lrp19.ch=0 and lrp19.sec=%s"""
			        
        self.sql_surv_line_r = """SELECT sec, 
			                     direction as surv_dir,
			                     'Lane 1' as lname, 
			                     0::float as start_ch, 
			                     sec_l as end_ch, 
			                     lrp_code as start_marker, 
			                     x as start_marker_x, 
			                     y as start_marker_y
                			     FROM lrp19
                			     WHERE lrp19.ch=sec_l and lrp19.sec=%s"""
        

    def sql(self, query, sec):
        dirs = {'NB':'SB', 'SB':'NB', 'EB':'WB', 'WB':'EB', 'CW':'CW', 'AC':'AC'}
        self.cur.execute(query, (sec, ))
        r=self.cur.fetchone()
        if r:
            row = dict(r)
            if not self.dir_f:
                if 'surv_dir' in row:
                    row['surv_dir'] = dirs[row['surv_dir']]
            return row
    
    #is the section a roundabout?
    def sql_isrbt(self, sec):
        sql = """SELECT funct_name 
                         FROM prog
                         WHERE sect_label = %s"""
        self.cur.execute(sql, (sec, ))
        try:
            row = self.cur.fetchone()[0]
        except:
            return False
        if row == 'RBT ':
            return True
        else:
            return False
        
    def sql_issinglec(self, sec):
        sql = """SELECT dual_name 
                         FROM prog
                         WHERE sect_label = %s"""
        self.cur.execute(sql, (sec, ))
        try:
            row = self.cur.fetchone()[0]
        except:
            return False
        if 'Two Way Single' in row:
            return True
        else:
            return False

    def dumy_surv_line(self, marker, x, y):
        dsec = dict(sec='', surv_dir='', lname='', start_ch=0, end_ch=0)
        dsec.update({'start_marker': marker, 'start_marker_x': x, 'start_marker_y': y})
        return self.surv_line.format(**dsec)

    #generate rte
    def make(self):
        
        for i, sec in enumerate(self.secs):
            sql_surv_line = self.sql_surv_line
            sql_end_route = self.sql_end_route
            if (not self.dir_f) and self.sql_issinglec(sec):
                sql_surv_line = self.sql_surv_line_r
                sql_end_route = self.sql_end_route_r
	
            if sec == 'D':
                dsec = self.sql(sql_end_route, self.secs[i-1])
                self.rows.append(self.dumy_surv_line(marker=dsec['end_marker'], x=dsec['end_marker_x'], y=dsec['end_marker_y']))
                self.__nsec += 1
                #continue
	
            elif self.sql_isrbt(sec):
                #it is Roundabout so, insert dummy section at entrance
                dsec = self.sql(sql_end_route, self.secs[i-1])
                self.rows.append(self.dumy_surv_line(marker=dsec['end_marker'], x=dsec['end_marker_x'], y=dsec['end_marker_y']))
                self.__nsec += 1
            
            
    	#inser rbt section
                row = self.sql(sql_surv_line, sec)
                if not row:
                    return 'No rows in table lrp19 with ch=0 and sect_label='+sec
                self.rows.append(self.surv_line.format(**row))
                self.__nsec += 1
                
    	#insert dumy section at exit
                dsec = self.sql(sql_end_route, sec)
                self.rows.append(self.dumy_surv_line(marker=dsec['end_marker'], x=dsec['end_marker_x'], y=dsec['end_marker_y']))
                self.__nsec += 1
     
            else:
	#insert normal section
                row = self.sql(sql_surv_line, sec)
                if not row:
                    return 'No rows in table lrp19 with ch=0 and sect_label='+sec
                self.rows.append(self.surv_line.format(**row))
                self.__nsec += 1

        #end route
        row = self.sql(sql_end_route, sec)
        self.rows.append(self.end_route.format(**row))
                        
        #sections
        self.secs.sort() #sort section in alphabetiacl order
        for i, sec in enumerate(self.secs):
            if sec != 'D':
                row = self.sql(self.sql_sect, sec)
                if not row:
                    return 'No rows in table prog with sect_label='+sec
                self.rows.append(self.sect.format(**row))
	
        #header
        row = self.header.format(file_format_ver='V1', route_ident=self.routeid, n_surv_lanes=self.__nsec)
        self.rows.insert(0, row) #add header on top
    
        return True
    
    def printf(self):
        for row in self.rows:
            print row,
            
    def save(self, rte_file):
        with open(rte_file, 'w') as rtefile:
            if platform.system() == 'Windows':
            	for row in self.rows:
            	    print >> rtefile, row
            if platform.system() == 'Linux':
                for row in self.rows:
                    print >> rtefile, row
        

if __name__ == "__main__":
        import optparse
        
        #parsing the comand line args
        parser=optparse.OptionParser()
        parser.add_option('-t', '--survey_id', help='survey', dest='survey_id', action='store', type='str')
        parser.add_option('-r', '--reversed_dir', help='reversed surv dir', dest='dir_f', action='store_false', default=True)
        parser.add_option('-D', '--dbname', help='pts scrim db', dest='dbname', action='store', type='str', default='hascrim')
        parser.add_option('-H', '--host', help='pts scrim db host', dest='dbhost', action='store', type='str', default='alderaan')
        #files store the file names to be processed
        (o, f) = parser.parse_args()
        
        secs = []
        with open(f[0], 'r') as secfile:
            for row in secfile:
                secs.append(row.strip())
        
        rte = hapms_make_rte(routeid=o.survey_id, db=o.dbname, host=o.dbhost, user='stuart', passwd='', secs=secs, dir_f=o.dir_f)
        print (o.dir_f)
        rte.make()
        rte.printf()
        rte.save(f[0].split('.')[0]+'.rte')
