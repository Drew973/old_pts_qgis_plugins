# -*- coding: utf-8 -*-

import os
from PyQt4 import QtGui, uic
from PyQt4.QtCore import pyqtSignal,QVariant


from collections import OrderedDict
from qgis.core import QgsMapLayerRegistry,QgsVectorLayer,QgsField,QgsFeatureRequest
#from PyQt4.QtGui import QDialog,QLineEdit, QPushButton,QVBoxLayout,QInputDialog
from qgis.utils import iface
import remaking as rm
from copy import deepcopy#,copy

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'route_builder_dockwidget_base.ui'))

	
	
class route_builderDockWidget(QtGui.QDockWidget, FORM_CLASS):

    closingPlugin = pyqtSignal()
    def __init__(self, parent=None):
        """Constructor."""
        super(route_builderDockWidget, self).__init__(parent)
        self.setupUi(self)

        self.routes=OrderedDict()
        self.text=''
        self.undos=[]
        self.redos=[]        

        self.clear_console.released.connect(self.cc)
        self.undo_button.released.connect(self.undo)
        self.redo_button.released.connect(self.redo)

        self.change.released.connect(self.backup)
        self.change.released.connect(self.edit_route)
        
        self.current_route.activated.connect(self.route_changed)
        
        self.nr.released.connect(self.new_route)
        
        self.add_sec.released.connect(self.maybe_add)
        
        self.del_route.released.connect(self.backup)
        self.del_route.released.connect(self.delete_route)

        self.del_map.released.connect(self.backup)
        self.del_map.released.connect(self.del_from_map)

        self.remove_selected_sec_button.released.connect(self.backup)
        self.remove_selected_sec_button.released.connect(self.remove_selected_sec)

        self.all_routes.toggled.connect(self.readd)
        
        self.init_layer()
        

    #create empty layer with fields route,description,direction
    def init_layer(self):
        self.layer_name,ok=QtGui.QInputDialog.getText(self,'Name','Name for new layer')
        
        self.layer=QgsVectorLayer('LineString?crs=epsg:27700',self.layer_name, 'memory')

        self.p=self.layer.dataProvider()
        new_fields=[QgsField("route",QVariant.String),QgsField("description",QVariant.String),QgsField("direction",QVariant.String)]
        self.p.addAttributes(new_fields)
        
        self.layer.updateFields()
        self.layer.commitChanges()
        QgsMapLayerRegistry.instance().addMapLayer(self.layer)
        

    def new_route(self):
        name,ok = QtGui.QInputDialog.getText(self, 'New Route','Name')

        if name=='':
            self.disp('A route needs a name')
            return
        
        if name in self.routes:
            self.disp('route: '+name+' already exists')
            return

        self.backup()
        self.disp('added new route:'+name)
        self.routes.update({name:{'desc':'','secs':[],'feats':[]}})
        self.refresh_routes()
        

    def edit_route(self):
        old_name=self.current_route.currentText()
        if old_name in self.routes:
            old_desc=self.routes[old_name]['desc']
        
            new_desc=self.route_desc.toPlainText()
            new_name=str(self.name_routes.text())
    
            #maybe rename
            if old_name!=new_name:
                self.routes[new_name]=self.routes.pop(old_name)
                self.disp('renamed '+old_name+' to '+new_name)
                self.refresh_routes()
    
            #maybe change desc
            if new_desc!=old_desc:
                self.routes[new_name]['desc']=new_desc      
                self.disp('changed description of '+new_name)
                self.route_desc.setPlainText(new_desc)
    
            #self.disp(self.routes)
            for f in self.routes[new_name]['feats']:
                f.setAttribute('desc',new_desc)#change feature['desc']
                f.setAttribute('route',new_name)


    def delete_route(self):
        r=self.current_route.currentText()
        if r=='':
            self.disp('no route selected')
        else:
            self.drop_feats(self.routes[r]['feats'])
            del(self.routes[r])
            self.refresh_routes()
            self.disp('deleted route '+r)


    #delete features from selected layer if in current route
    def del_from_map(self):
        sf=iface.activeLayer().selectedFeatures()
        cr=self.routes[self.current_route.currentText()]

        for f in sf:
            try:
                sl=self.sec_lab(f['feature_id'],f['direction'])
                if sl in cr['secs']:
                    i=cr['secs'].index(sl)
                    self.remove_by_index(i)
            except:
                pass

            
    def remove_selected_sec(self):
        i=self.sections_list.currentRow()
        self.remove_by_index(i)


    #delete from current_route given index(position in feats and secs)
    def remove_by_index(self,i):
        cr=self.routes[self.current_route.currentText()]
        f=cr['feats'].pop(i)
        self.drop_feats([f])#removes from list,then from layer        
        self.disp('removed '+cr['secs'].pop(i))#removes sec from list
        self.refresh_secs()
        

    def refresh_routes(self):
        rn=[]
        for i in self.routes:
            rn.append(i)
        #r=rn[::-1]#invert
        
        self.current_route.clear()
        self.current_route.addItems(rn)
        #self.current_route.setCurrentIndex(0)
        self.route_changed()
        
        
    def route_changed(self):
        #routes
        route=self.current_route.currentText()
        self.name_routes.setText(route)
        if route in self.routes:
            d=self.routes[route]['desc']
            self.route_desc.setPlainText(d)

        if self.only_route.isChecked():
            self.readd()
            
        self.refresh_secs()
        

    def maybe_add(self):
        sf=iface.activeLayer().selectedFeatures()
        L=len(sf)

        #nothing selected
        if L==0:
            self.disp('nothing selected, is layer active?')
            return

        #>1 item selected
        if L>1:
            self.disp('>1 feature selected')
            return

        #no route selected
        route=self.current_route.currentText()
        if route=='':
            self.disp('No route selected')
            return

        #no row in sections_list selected and >0 sections in route
        cr=self.sections_list.currentRow()#-1 if none selected 
        if cr==-1 and len(self.routes[route]['secs'])>0:
            self.disp('no row selected')
            return

        #start_node!=end_node
        
        if self.CL.isChecked():
            direction='CL'
        else:
            direction='CR'

        section=sf[0][self.section_field.text()]
        sl=self.sec_lab(section,direction)
        message='added '+sl+'.'
        
        #duplicates
        if sl in self.routes[route]['secs']:
            if not self.duplicates.isChecked():
                self.disp('already have :'+sl) 
                return
            else:
                message+=' Duplicate.'

        if self.after.isChecked():
            i=cr+1
        else:
            i=cr

        desc=self.routes[route]['desc']
        feat=sf[0]
        
        gn={'gap':False,'mismatch':False}

        if len(self.routes[route]['secs'])>1:
            f2=self.routes[route]['feats'][cr]
            gn=self.gap_check(old=f2,new=feat,new_dir=direction)


        if gn['gap']:
            if not self.allow_gap.isChecked():
                self.disp('Gap>'+str(self.gap_size.value())+'. Not allowed.')
                return
            else:
                message+=' Gap >'+str(self.gap_size.value())+'.'
              

        if gn['mismatch']:
            if not self.allow_mismatch.isChecked():
                self.disp('Nodes Mismatch. Not allowed.')
                return
            else:
                message+=' Nodes mismatch.'

        #adding
        self.backup()
        rm.fix_fields(self.layer,feat)
        f=rm.remake_feat(self.layer,feat,direction,route,desc)
        self.routes[route]['secs'].insert(i,sl)   
        self.routes[route]['feats'].insert(i,f)
        self.refresh_secs(i=i)
        self.disp_feats([f])
        self.disp(message)


    def sec_lab(self,section,direction):
        return section+'_'+direction
        

#refreshes sections_list list
    def refresh_secs(self,i=0):
        self.sections_list.clear()
        route=self.current_route.currentText()
        if route!='':
            L=len(self.routes[route]['secs'])
            if L>0:
                secs=self.routes[route]['secs']
                self.sections_list.addItems(secs)
                self.sections_list.setCurrentRow(i)


    def gap_check(self,old,new,new_dir):
       #end of old to start of new
        if self.after.isChecked():
            start=old
            start_dir=old['direction']
            end_dir=new_dir
            end=new

        #new to old
        if self.before.isChecked():
            start=new
            start_dir=new_dir
            end_dir=old['direction']
            end=old
            
        if start_dir=='CL':
            start_p=start.geometry().asPolyline()[-1]
            start_node=start['end_node']
            
        if start_dir=='CR':
            start_p=start.geometry().asPolyline()[0]
            start_node=start['start_node']
            
        if end_dir=='CL':
            end_p=end.geometry().asPolyline()[0]
            end_node=end['start_node']
            
        if end_dir=='CR':
            end_p=end.geometry().asPolyline()[-1]
            end_node=end['end_node']
            
        res={'gap':False,'mismatch':False}     
        
        if start_p.sqrDist(end_p)>self.gap_size.value()*self.gap_size.value():
            res['gap']=True
            
        if end_node!=start_node:
            res['mismatch']=True
            
        return res
                                 

    def drop_view(self):
        sf=self.iface.activeLayer().selectedFeatures()
        self.remove_secs(sf)


    def readd(self):
        route=self.current_route.currentText()

        self.layer.startEditing()
        for f in self.layer.getFeatures():
            self.layer.deleteFeature(f.id())
        self.layer.commitChanges()
 
        for n in self.routes:
            cr=self.routes[n]
            if self.all_routes.isChecked() or n==route:#route==current route
                self.disp_feats(cr['feats'])
                
                    
    def disp_feats(self,feats):
        self.layer.startEditing()
        for f in feats:
            self.layer.addFeature(f)
        self.layer.commitChanges()
        self.layer.updateExtents()
        self.refresh_map()
        

    def drop_feats(self,feats):
        s=[]
        for i in feats:
            s.append(self.sec_lab(i['feature_id'],i['direction']))

        route=self.current_route.currentText()
        q='"route"'+'='+"'"+route+"'"
        #"route"='a'#"for fields. 'for strings
        request = QgsFeatureRequest().setFilterExpression(q)
        self.layer.startEditing()
        for f in self.layer.getFeatures(request):#features of self.layer in current route
            if self.sec_lab(f['feature_id'],f['direction']) in s:
                self.layer.deleteFeature(f.id())

        self.layer.commitChanges()   
        self.refresh_map()    

        
    def refresh_map(self):
        if iface.mapCanvas().isCachingEnabled():
            self.layer.triggerRepaint()
        else:
            iface.mapCanvas().refresh()
                 
    #clear console     
    def cc(self):
        self.disp('',overwrite=True)
        
    def disp(self,text,overwrite=False):
        if isinstance(text,list):
            t=[]
            for i in text:
                t.append(str(i))
            text=','.join(t)#needs str,not int or float
        else:
            text=str(text)
        if overwrite:
            self.text=text
        else:
            self.text=self.text+'\n'+text
        self.display.setText(self.text)
        scrollBar=self.display.verticalScrollBar();
        scrollBar.setValue(scrollBar.maximum()) #scroll to end


#undo and redo
    def backup(self):
        self.undo_length=15
        #self.undos.append({'routes':self.copy_state()})
        self.undos.append(state(self))
        self.redos=[]
        self.undo_button.setFlat(False)
        
        if len(self.undos)>self.undo_length:
            self.undos.remove(self.undos[0])
            
    def set_state(self,state):
        
        #set fields
        if state.fields!=self.layer.fields():
            QgsMapLayerRegistry.instance().removeMapLayer( self.layer.id() )
            self.layer=QgsVectorLayer('LineString?crs=epsg:27700',state.layer_name, 'memory')
            self.layer.dataProvider().addAttributes(state.fields)
            self.layer.updateFields()
            self.layer.commitChanges()
            QgsMapLayerRegistry.instance().addMapLayer(self.layer)

        
        self.routes=state.routes
        self.refresh_routes()
        self.refresh_secs()
        self.readd()
        self.disp(state.text,overwrite=True)
        
        
    def undo(self):
        if len(self.undos)==0:
            #self.disp('out of undos')
            return
        self.redos.append(state(self))
        self.set_state(self.undos.pop())
        self.redo_button.setFlat(False)
        if len(self.undos)==0:
            self.undo_button.setFlat(True)
        
    def redo(self):
        if len(self.redos)==0:
           # self.disp('out of redos')
            return
        self.undos.append(state(self)) 
        self.undo_button.setFlat(False)
        self.set_state(self.redos.pop())
        if len(self.redos)==0:
            self.redo_button.setFlat(True)


    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()


class state:
    def __init__(self,rbdw):
        self.routes=self.copy_routes(rbdw.routes)
        self.text=rbdw.text
        self.fields=rbdw.layer.fields()
        self.layer_name=rbdw.layer_name

    def copy_routes(self,routes):
        backup=OrderedDict()
        for route in routes:
            d=deepcopy(routes[route]['desc'])
            secs=routes[route]['secs'][:]
            feats=routes[route]['feats'][:]##features need reference otherwise error. Need shallow copy of feats       
            row={'desc':d,'secs':secs,'feats':feats}#but copy.copy(self.routes) creates reference to list
            backup[route]=row
        return backup
                                           
